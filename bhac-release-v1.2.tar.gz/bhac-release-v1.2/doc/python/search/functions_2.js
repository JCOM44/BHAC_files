var searchData=
[
  ['extract',['extract',['../namespaceread.html#a565fbd6a03d2869132df93c79903a6d4',1,'read']]]
];
