var searchData=
[
  ['blockheight',['blockHeight',['../classamrplot_1_1polyplot.html#a5c8367ebb60afa6ba651e0b807a01785',1,'amrplot::polyplot']]],
  ['blocks',['blocks',['../classamrplot_1_1polyplot.html#a81c5cd47348d2861c881942d2999d193',1,'amrplot::polyplot']]],
  ['blockwidth',['blockWidth',['../classamrplot_1_1polyplot.html#a29c84da3b093ab0e75852a539cc07e3f',1,'amrplot::polyplot']]]
];
