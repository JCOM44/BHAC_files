var searchData=
[
  ['amrplot',['amrplot',['../namespaceamrplot.html',1,'']]],
  ['amrplot_2epy',['amrplot.py',['../amrplot_8py.html',1,'']]],
  ['ax',['ax',['../classamrplot_1_1polyplot.html#a23abee13884b44ba719e68de657932f8',1,'amrplot.polyplot.ax()'],['../classamrplot_1_1rgplot.html#a21b37c48566571f772862fa13f3ca018',1,'amrplot.rgplot.ax()']]]
];
