var searchData=
[
  ['data',['data',['../classread_1_1load.html#ac64460ad2b6a4c0f797144570d2fd06d',1,'read.load.data()'],['../classread_1_1particles.html#a0c543ccbdaa06e9c550e04c3198c4b8a',1,'read.particles.data()'],['../classread_1_1ensemble.html#a2f031213fdd622c9082972e0e8b5842d',1,'read.ensemble.data()'],['../classread_1_1postrad.html#a7728686955a92215402747ba0273bafd',1,'read.postrad.data()'],['../classamrplot_1_1polyplot.html#a587a5bf4f0fbb879ff6d934778d715a2',1,'amrplot.polyplot.data()']]],
  ['datareader',['datareader',['../classread_1_1load.html#a401ef2a1be2c80e6648e72eab0a088ef',1,'read.load.datareader()'],['../classread_1_1loadvti.html#a7c3f47b6f63d95f732a2268611249e55',1,'read.loadvti.datareader()']]],
  ['default_5ftimer',['default_timer',['../namespaceread.html#a0ffc2818a4b9a8753985d1fd9095e02f',1,'read.default_timer()'],['../namespaceamrplot.html#a29460b111d807c4745b5a83ec9c4e806',1,'amrplot.default_timer()']]],
  ['delimiter',['delimiter',['../classread_1_1ensemble.html#a05a1bd0b7cf899b0086324ff3f1aa49a',1,'read::ensemble']]],
  ['dir',['dir',['../classread_1_1loadcsv.html#a393623cc06389bb367caa1b5f50cdcbc',1,'read::loadcsv']]],
  ['dpi',['dpi',['../classamrplot_1_1polyplot.html#a4c90969c3e1129a1834a585c7d3f4971',1,'amrplot::polyplot']]],
  ['dx',['dx',['../classread_1_1loadvti.html#ac8c946af81ea0255e105f170cc7d6989',1,'read::loadvti']]],
  ['dy',['dy',['../classread_1_1loadvti.html#ab922dedf68b58cfb153106a56232c754',1,'read::loadvti']]],
  ['dz',['dz',['../classread_1_1loadvti.html#acbf4aa852c25400527565c0e9d5c024c',1,'read::loadvti']]]
];
