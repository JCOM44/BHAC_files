var searchData=
[
  ['ncells',['ncells',['../classread_1_1load.html#ae91bc8058ebcce892cd5815e439f30a7',1,'read::load']]],
  ['ndim',['ndim',['../classread_1_1load.html#a51e5b392f3ae3b772ee01b47d7f5f68e',1,'read.load.ndim()'],['../classread_1_1loadvti.html#a6e0f9ec85ea944a3799560cf10071392',1,'read.loadvti.ndim()']]],
  ['nlevel1',['nlevel1',['../classamrplot_1_1polyplot.html#aa33cf388a5f835794a3f748d2a2e6142',1,'amrplot::polyplot']]],
  ['nlevels',['nlevels',['../classamrplot_1_1polyplot.html#adb1afa4c961a231a487f669c396dec8b',1,'amrplot::polyplot']]],
  ['npayload',['npayload',['../classread_1_1ensemble.html#ac731446647c6dcab94c5c7194c52bd37',1,'read::ensemble']]],
  ['nvars',['nvars',['../classread_1_1postrad.html#af137169b84fd8307bbdcc7af1422e314',1,'read::postrad']]],
  ['nx',['nx',['../classread_1_1loadvti.html#afcdbc9fa6bf1e15958d83c441ff65c3b',1,'read::loadvti']]],
  ['ny',['ny',['../classread_1_1loadvti.html#a9f8b82780a2d4717d2284aefc3329ae1',1,'read::loadvti']]],
  ['nz',['nz',['../classread_1_1loadvti.html#a7affadee54322388a57d52f1bba1121c',1,'read::loadvti']]]
];
