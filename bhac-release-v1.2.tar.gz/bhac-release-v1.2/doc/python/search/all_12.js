var searchData=
[
  ['update',['update',['../classamrplot_1_1polyplot.html#ac1937bf6f143c5e37afd2045efadf0ab',1,'amrplot::polyplot']]]
];
