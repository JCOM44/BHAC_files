var searchData=
[
  ['x',['x',['../classread_1_1loadvti.html#ad8a6fdb88386dce051cdade16bf426a1',1,'read::loadvti']]],
  ['xblocklist',['xBlockList',['../classread_1_1load.html#a1a6dee8c6f0359543b0778b3f6910fe1',1,'read::load']]],
  ['xlist',['xlist',['../classread_1_1load.html#a0c7c5ed9c7c6753b8d79bea2c7f2dc0c',1,'read.load.xlist()'],['../classamrplot_1_1polyplot.html#a6305f6fde84067be441b72203ecb8c05',1,'amrplot.polyplot.xlist()']]],
  ['xlistspecial',['xlistspecial',['../classamrplot_1_1polyplot.html#a541e29f748019c94720ef8a79c86a506',1,'amrplot::polyplot']]],
  ['xrange',['xrange',['../classamrplot_1_1polyplot.html#ab2e85991ae46edf094b98591597e6f87',1,'amrplot::polyplot']]]
];
