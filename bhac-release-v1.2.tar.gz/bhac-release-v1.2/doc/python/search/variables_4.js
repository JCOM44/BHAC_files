var searchData=
[
  ['edgecolor',['edgecolor',['../classamrplot_1_1polyplot.html#a5ed545d5a3d46b801c55f43cd78db4da',1,'amrplot::polyplot']]]
];
