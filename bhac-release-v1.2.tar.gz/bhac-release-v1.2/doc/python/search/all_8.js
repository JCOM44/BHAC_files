var searchData=
[
  ['header',['header',['../classread_1_1loadcsv.html#ace92617fcfabe29eaa166bf3f1ee9b4a',1,'read.loadcsv.header()'],['../classread_1_1postrad.html#a644306c413ccbd2a866b976e6320ba7c',1,'read.postrad.header()']]],
  ['headersize',['headersize',['../classread_1_1postrad.html#ae4d5d511a98dcc093adf149f87f2902c',1,'read::postrad']]]
];
