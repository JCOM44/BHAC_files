var searchData=
[
  ['max',['max',['../classamrplot_1_1polyplot.html#ab2a017599999c1ce42d0064210d109b4',1,'amrplot::polyplot']]],
  ['maxxticks',['maxXticks',['../classamrplot_1_1polyplot.html#a85920df666ae260ca538009663784224',1,'amrplot::polyplot']]],
  ['maxyticks',['maxYticks',['../classamrplot_1_1polyplot.html#a2b9753d3eaca0da5d0482cc3b84a8ec2',1,'amrplot::polyplot']]],
  ['min',['min',['../classamrplot_1_1polyplot.html#a0cf63954fad1b67dc007b5c60901f41d',1,'amrplot::polyplot']]],
  ['mirrorplane',['mirrorPlane',['../classread_1_1load.html#aa2f320acb65fb1894dbfbfd8bbc48773',1,'read.load.mirrorPlane()'],['../classread_1_1loadvti.html#a3708b02adf2030ad17a01576c01de84b',1,'read.loadvti.mirrorPlane()']]],
  ['mynparticles',['mynparticles',['../classread_1_1particles.html#a543d99387d215f5518c564bf70d0fd15',1,'read::particles']]]
];
