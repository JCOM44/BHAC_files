var searchData=
[
  ['save',['save',['../classamrplot_1_1polyplot.html#a7e289ef0020a669b88ce755f8efb1b55',1,'amrplot::polyplot']]],
  ['setvalue',['setValue',['../classamrplot_1_1polyplot.html#ad075ca37613d6b45358b6b587fa9eaf7',1,'amrplot::polyplot']]],
  ['show',['show',['../classamrplot_1_1polyplot.html#a5f4513841bc234e6c3867612619397f9',1,'amrplot.polyplot.show()'],['../classamrplot_1_1rgplot.html#a605dcda9919cf3771d6310b0b62b4e74',1,'amrplot.rgplot.show()']]],
  ['showvalues',['showValues',['../classread_1_1load.html#afb1e9522707b420ce82db3b63c2caea9',1,'read::load']]],
  ['streamline',['streamline',['../namespaceamrplot.html#a214eccffe1d56a25d80925cc453f5a23',1,'amrplot']]],
  ['streamlines',['streamlines',['../namespaceamrplot.html#afd42022e288c73e942784cf1207fa538',1,'amrplot']]]
];
