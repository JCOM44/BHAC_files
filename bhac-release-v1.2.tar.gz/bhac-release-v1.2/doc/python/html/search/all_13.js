var searchData=
[
  ['value',['value',['../classamrplot_1_1polyplot.html#ae3180174a756fa4799398482a15126ed',1,'amrplot::polyplot']]],
  ['valueclip',['valueClip',['../classamrplot_1_1polyplot.html#a5b26747a317d05e14dd92a60c6afd48d',1,'amrplot.polyplot.valueClip()'],['../classamrplot_1_1rgplot.html#a7dac12ca8230c648f68fb7eaa192b6a1',1,'amrplot.rgplot.valueClip()']]],
  ['velovect',['velovect',['../namespaceamrplot.html#ac900799ef23a01f0ec851965aaa9b938',1,'amrplot']]],
  ['viewxrange',['viewXrange',['../classamrplot_1_1polyplot.html#a625a7944102bc45ab97068cef091a8fa',1,'amrplot.polyplot.viewXrange()'],['../classamrplot_1_1rgplot.html#adadf75fb79fd9b699e3aa047c9fe68ef',1,'amrplot.rgplot.viewXrange()']]],
  ['viewyrange',['viewYrange',['../classamrplot_1_1polyplot.html#a585225c48f14bcde418afbfb88fb2b49',1,'amrplot.polyplot.viewYrange()'],['../classamrplot_1_1rgplot.html#ae7316449020fc15b382ad9d29be8de5a',1,'amrplot.rgplot.viewYrange()']]]
];
