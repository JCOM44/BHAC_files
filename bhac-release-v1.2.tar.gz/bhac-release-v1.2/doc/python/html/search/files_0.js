var searchData=
[
  ['amrplot_2epy',['amrplot.py',['../amrplot_8py.html',1,'']]]
];
