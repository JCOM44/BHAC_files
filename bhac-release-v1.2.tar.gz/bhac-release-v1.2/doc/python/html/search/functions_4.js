var searchData=
[
  ['info',['info',['../classamrplot_1_1polyplot.html#a9a62a404614d1835054a8b76e587058f',1,'amrplot::polyplot']]]
];
