var searchData=
[
  ['rgplot',['rgplot',['../classamrplot_1_1rgplot.html',1,'amrplot']]]
];
