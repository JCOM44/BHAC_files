var searchData=
[
  ['blocks',['blocks',['../classamrplot_1_1polyplot.html#a81c5cd47348d2861c881942d2999d193',1,'amrplot::polyplot']]],
  ['bob',['bob',['../classamrplot_1_1line.html#a3c7ee73532e0c42e9ff6f0cb18c3ff7d',1,'amrplot::line']]]
];
