var searchData=
[
  ['n',['n',['../classamrplot_1_1line.html#ab39d679feda9c06436590c937a579443',1,'amrplot::line']]],
  ['nblocks',['nblocks',['../classread_1_1load.html#a5a52653ac47d11deeb241cd80c28abc2',1,'read::load']]],
  ['ncells',['ncells',['../classread_1_1load.html#ae91bc8058ebcce892cd5815e439f30a7',1,'read::load']]],
  ['ndim',['ndim',['../classread_1_1load.html#a51e5b392f3ae3b772ee01b47d7f5f68e',1,'read.load.ndim()'],['../classread_1_1loadvti.html#a6e0f9ec85ea944a3799560cf10071392',1,'read.loadvti.ndim()']]],
  ['nlevels',['nlevels',['../classamrplot_1_1polyplot.html#adb1afa4c961a231a487f669c396dec8b',1,'amrplot.polyplot.nlevels()'],['../classamrplot_1_1polyanim.html#a4c4dfc073cb0b756c8d51ac891b4d516',1,'amrplot.polyanim.nlevels()']]],
  ['npayload',['npayload',['../classread_1_1ensemble.html#ac731446647c6dcab94c5c7194c52bd37',1,'read::ensemble']]],
  ['nx',['nx',['../classread_1_1loadvti.html#afcdbc9fa6bf1e15958d83c441ff65c3b',1,'read::loadvti']]],
  ['ny',['ny',['../classread_1_1loadvti.html#a9f8b82780a2d4717d2284aefc3329ae1',1,'read::loadvti']]],
  ['nz',['nz',['../classread_1_1loadvti.html#a7affadee54322388a57d52f1bba1121c',1,'read::loadvti']]]
];
