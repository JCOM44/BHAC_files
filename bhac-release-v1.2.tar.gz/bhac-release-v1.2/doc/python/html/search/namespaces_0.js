var searchData=
[
  ['amrplot',['amrplot',['../namespaceamrplot.html',1,'']]]
];
