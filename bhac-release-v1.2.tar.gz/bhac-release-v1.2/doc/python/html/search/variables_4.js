var searchData=
[
  ['edgecolor',['edgecolor',['../classamrplot_1_1polyplot.html#a5ed545d5a3d46b801c55f43cd78db4da',1,'amrplot::polyplot']]],
  ['epsilon',['epsilon',['../classamrplot_1_1line.html#adcd6717209fa5af1999acbcdf5a54c53',1,'amrplot::line']]]
];
