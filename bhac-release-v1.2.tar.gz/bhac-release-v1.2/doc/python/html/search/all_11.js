var searchData=
[
  ['time',['time',['../classread_1_1load.html#ad70b4c176853f4781e1e414b015c7c48',1,'read::load']]],
  ['type',['type',['../classread_1_1load.html#aef4ca30f8a6333ae4c0d7e9f285a69bf',1,'read.load.type()'],['../classamrplot_1_1polyanim.html#a178a556f18f8566cda446dc095993e6c',1,'amrplot.polyanim.type()']]]
];
