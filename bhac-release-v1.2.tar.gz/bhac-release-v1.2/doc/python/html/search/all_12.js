var searchData=
[
  ['update',['update',['../classamrplot_1_1polyplot.html#a6ba1ffe598d62953ea89c2aa6829c4e9',1,'amrplot::polyplot']]]
];
