var searchData=
[
  ['grid',['grid',['../classamrplot_1_1polyplot.html#a4039d8b2cd9bba5ae4dff768e92fe3cd',1,'amrplot.polyplot.grid()'],['../classamrplot_1_1polyanim.html#a67d0f67d64ca4a0245b19b4caaa2724f',1,'amrplot.polyanim.grid()']]]
];
