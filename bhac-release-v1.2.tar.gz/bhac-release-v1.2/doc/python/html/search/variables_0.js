var searchData=
[
  ['alice',['alice',['../classamrplot_1_1line.html#a0e4f76d15019bfa57502833660a0c4b7',1,'amrplot::line']]],
  ['ax',['ax',['../classamrplot_1_1polyplot.html#a23abee13884b44ba719e68de657932f8',1,'amrplot.polyplot.ax()'],['../classamrplot_1_1rgplot.html#a21b37c48566571f772862fa13f3ca018',1,'amrplot.rgplot.ax()']]]
];
