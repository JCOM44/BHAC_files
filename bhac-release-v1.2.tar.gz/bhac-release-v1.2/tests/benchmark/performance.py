from pylab import *

d=loadtxt('output/amrvac.log',usecols=[24],skiprows=3)

print('Average number of cellupdates per second per core:', d.mean())
print('Fastest step:', d.max())
print('slowest step:', d.min())
print('stddev:', d.std())
