##################################################################################################

Orszag-Tang vortex

Orszag, SA, Tang, C-M: Small-scale structure of two-dimensional magnetohydrodynamic turbulence.
J. Fluid Mech. 90, 129-143 (1979). doi:10.1017/S002211207900210X

O. Porth, H. Olivares, Y. Mizuno, Z. Younsi, L. Rezzolla, M. Moscibrodzka, H. Falcke, and
M. Kramer. The black hole accretion code. Computational Astrophysics and Cosmology,
4:1, May 2017. doi: 10.1186/s40668-017-0020-2.

##################################################################################################

2D case:

$BHAC_DIR/setup.pl -d=23 -phi=2 -z=3 -g=12,12 -p=rmhd -eos=default -nf=0 -arch=default -coord=cart

definitions.h:

#define STAGGERED
#define PARTICLES
#define PARTICLES_ADVECT
