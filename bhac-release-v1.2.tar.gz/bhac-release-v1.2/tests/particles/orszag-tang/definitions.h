#define STAGGERED
