# Overview of the tests folder

Some standard verified tests can be found here, sorted by physics module.  Typically you only have to adjust the compiler options by running
```
$BHAC_DIR/setup.pl -arch=XXX
```

where XXX could e.g. be *default* or *gfortran* (*default* is actually the intel compiler!), see $BHAC_DIR/doc/GettingStarted.html for installation instructions.

## benchmark

This is a 2D Fishbone Moncrief GRMHD torus often used for benchmarking machines.  You can find some performance metrics to compare and check your configuration in the *results* subfolder.

## rmhd

lists a couple of standard test described further in [Porth et al. (2017)](https://comp-astrophys-cosmol.springeropen.com/articles/10.1186/s40668-017-0020-2) and [Olivares et al. (2019)](https://doi.org/10.1051/0004-6361/201935559).
Most tests are 2D and should run quickly on a workstation.  
