#undefine EPSINF
#undefine GLM
#define STAGGERED
#define ENTROPY
