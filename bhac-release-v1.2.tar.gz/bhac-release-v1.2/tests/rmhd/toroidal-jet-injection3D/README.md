This setup injects a jet with toroidal magnetic field into the domain. 
The jet configuration follows the 'core-envelope' setup in 
https://ui.adsabs.harvard.edu/abs/2015MNRAS.452.1089P
(and previously Komissarov 1999)

The core is highly unstable to non-axisymmetric pressure driven modes. 
