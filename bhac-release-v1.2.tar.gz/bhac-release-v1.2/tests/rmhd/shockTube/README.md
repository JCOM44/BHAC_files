# Relativistic Shock Tube Test

Reference:
O. Porth, H. Olivares, Y. Mizuno, Z. Younsi, L. Rezzolla, M. Moscibrodzka, H. Falcke, and
M. Kramer. The black hole accretion code. Computational Astrophysics and Cosmology,
4:1, May 2017. doi: 10.1186/s40668-017-0020-2.

See Section 3.1. for details.  


The parameters are:
```
    eqpar(gamma_) = 2.0d0 ! Adiabatic index
    eqpar(swap_)  =+1.0d0 ! muliply x with this to swap Riemann problem.
```


## RUNNING THE SET-UP

### To run the 1D case:
deactivate STAGGERED mesh in definitions.h:
```
#undefine STAGGERED
```
set up for 1D:
```
$BHAC_DIR/setup.pl -d=13 -phi=3 -z=2 -g=12 -p=rmhd -eos=gamma -nf=0 -arch=gfortran -coord=cart
```

```
make clean && make
```

```
mkdir output
```

```
mpiexec -n 8 ./bhac -i amrvac1D.par
```

### To run the 3D case:

activate STAGGERED mesh in definitions.h:
```
#define STAGGERED
```
set up for 3D:

```
$BHAC_DIR/setup.pl -d=33 -phi=2 -z=3 -g=12,12,12 -p=rmhd -eos=default -nf=0 -arch=gfortran -coord=cart

```

```
make clean && make
```

```
mpiexec -n 8 ./bhac -i amrvac3D.par
```

