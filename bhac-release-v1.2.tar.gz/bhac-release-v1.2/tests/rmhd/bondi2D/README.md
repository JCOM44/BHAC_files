# 2D bondi accretion onto Schwarzschild black hole

This test is described in [Porth et al. (2019)](https://comp-astrophys-cosmol.springeropen.com/articles/10.1186/s40668-017-0020-2), Section 3.5.2.  Its an axisymmetric setup of spherical accretion onto a Schwarzschild black hole.

The parameters are:
```
gamma = 4/3
rc = 8
sigma = 1000  
```

Note that this setup employs staggered grid though as opposed to the FCT and GLM variant shown in the paper.

