# Gardiner & Stone's loop advection test

The purpose of this test is to study the ability of magnetic
field evolution algorithms to preserve the shape of a weak
magnetic field loop that is passively advected.
This is better achieved by upwinded methods as those of
Londrillo & Del Zanna 2004 (UCT1), Gardiner & Stone 2005
(not implemented) and Del Zanna et al. 2007 (UCT2).

References:
Gardiner, T. A. & Stone, J. M. 2005, Journal of Computational Physics, 205, 509

## RUNNING THE SET-UP

1. To configure the set-up, which runs in 2D, run:

```
$BHAC_DIR/setup.pl -d=23 -phi=2 -z=3 -g=16,16 -p=rmhd -eos=default nf=0 -arch=gfortran -coord=cart
```

2. Erase previous executables and create a new one with

```
make clean && make
```

3. Create an output folder named 'output'

```
mkdir output
```

4. Run the executable in parallel, for example, as
```
mpirun -n 10 ./bhac
```

This should produce a series of snapshot (*.dat)
and visualization (*.vtu) files in the directory 'output'.

## TESTING DIFFERENT B-EVOLUTION METHODS

The current set up evolves the magnetic field using the
UCT2 algorithm. To compare the results with those of a
non-upwind evolution algorithm, let us run it with the
arithmetic averaging method by Balsara & Spicer 1999.

1. Create a different directory, e.g.

```
mkdir output2
```

2. Edit the parameter file, amrvac.par, to change the I/O
directories. In the filelist, change:

        filenameout       = 'output2/data'
        filenameini       = 'output2/data'
        filenamelog       = 'output2/amrvac'
-->
        filenameout       = 'output2/data'
        filenameini       = 'output2/data'
        filenamelog       = 'output2/amrvac'

3. In the same file, in the method list change

        typeemf           = 'uct2'
-->
        typeemf           = 'average'

4. Run as before, with 
```
mpirun -n 10 ./bhac
```
This should produce a series of snapshot (*.dat)
and visualization (*.vtu) files in the directory 'output2'.

5. When comparing the results obtained with both methods,
it is expected that uct2 will show a better preservation of the
loop original magnetic field shape.

