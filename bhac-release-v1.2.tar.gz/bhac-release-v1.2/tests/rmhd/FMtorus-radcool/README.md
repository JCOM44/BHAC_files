Fishbone-Moncrief torus with electron-heating and cooling.

See Dihingia et al. for implemenation details.
https://ui.adsabs.harvard.edu/abs/2023MNRAS.518..405D

You can set parameters for electronphysics in the name-list 'electronphys' in the parameter file.
