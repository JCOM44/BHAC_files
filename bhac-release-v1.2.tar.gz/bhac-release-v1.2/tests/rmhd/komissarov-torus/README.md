# Magnetized equilibrium torus

S. S. Komissarov's equilibrium torus with a toroidal magnetic field in 2D and 3D.  

References:
S. S. Komissarov. Magnetized tori around Kerr black holes: analytic solutions with a toroidal magnetic field. Mon. Not. R. Astron. Soc., 368:993–1000, May 2006.
doi: 10.1111/j.1365-2966.2006.10183.x.

O. Porth, H. Olivares, Y. Mizuno, Z. Younsi, L. Rezzolla, M. Moscibrodzka, H. Falcke, and
M. Kramer. The black hole accretion code. Computational Astrophysics and Cosmology,
4:1, May 2017. doi: 10.1186/s40668-017-0020-2.

See Section 3.4. for details.  

The parameters are:
```
    eqpar(gamma_)    = 4.0d0/3.0d0    ! Adiabatic index
    eqpar(kappa_)    = 4.0d0/3.0d0    ! Index for the Barotropic initial condition
                                      ! Implemented for the case kappa=eta:
                                      ! p = K omega**kappa; pmtilde = Km omegatilde**kappa

    eqpar(rc_)       = 4.62d0         ! Center radius in BL coordinates
    eqpar(rcusp_)    = 1.8d0          ! Assumed cusp radius in BL coordinates (solution within rcusp set to atmo)
    eqpar(l_)        = 2.8d0          ! Angular momentum
    eqpar(dW_)       = 0.073d0        ! Potential gap

    eqpar(omegac_)   = 1.0d0          ! Central enthalpy rho*h
    eqpar(beta_)     = 0.1d0          ! Central plasma-beta

    eqpar(rhomin_)   = 1.0d-5         ! Atmosphere scaling density
    eqpar(pmin_)     = 1.0d-7         ! Atmosphere scaling pressure

    eqpar(m_)        = 1.0d0          ! Black hole mass
    eqpar(a_)        = 0.9d0          ! Spin parameter

    coordpar(h_)     = 0.0d0          ! MKS h-parameter
    coordpar(R0_)    = 0.0d0          ! MKS R0-parameter
```


## RUNNING THE SET-UP

### To run the 2D case:
```
$BHAC_DIR/setup.pl -d=23 -phi=3 -z=2 -g=24,24 -p=rmhd -eos=gamma -nf=1 -arch=gfortran -coord=mks
```
```
make clean && make
```

```
mkdir output
```

```
mpiexec -n 20 ./bhac
```

### To run the 3D case:

```
$BHAC_DIR/setup.pl -d=33 -phi=3 -z=2 -g=24,24,24 -p=rmhd -eos=gamma -nf=1 -arch=gfortran -coord=mks
```

```
make clean && make
```

```
mpiexec -n 20 ./bhac -i amrvac3D.par
```


