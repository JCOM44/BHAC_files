# 2D axisymmetric Font and Daigne Torus (SANE)

This is a widely coordinate independent implementation of a constant angular momentum torus following Font and Daigne (2002) [https://ui.adsabs.harvard.edu/abs/2002MNRAS.334..383F/abstract]

Note that this uses ``the other`` definition of the angular momentum compared to the FMtorus setup.  Here we use l:=-  u_\phi / u_t .  The difference is discussed in Kozlowsky et al. (1978) [https://ui.adsabs.harvard.edu/abs/1978A&A....63..209K/abstract].

The only coordinate dependent parameter is the inner disk radius eqpar(rin_).  It is assumed to be given in Boyer-Lindquist coordinates.  It is easy to modify this though.  

The parameters are:
```
  eqpar(gamma_)    = 4.0d0/3.0d0         ! Adiabatic index

  eqpar(a_)        = 0.9375d0            ! Spin parameter
  eqpar(kappa_)    = 1.0d-3              ! entropy (will be re-normalized)
  
  eqpar(rin_)      = 6.0d0               ! inner radius
  eqpar(l_)        = 3.66459328781385d0  ! Angular momentum

  eqpar(m_)        = 1.0d0               ! Black hole mass

  eqpar(beta_)     = 1.0d+2              ! Measure for Plasma-beta
  eqpar(rhomin_)   = 1.0d-5              ! Minimum density scale
  eqpar(pmin_)     = 1.0d-7              ! Minimum pressure scale
```
