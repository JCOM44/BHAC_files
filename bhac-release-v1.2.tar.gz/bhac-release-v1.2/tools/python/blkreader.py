"""
Simple reader class for bhac postrad data.
Usage example: d=read(offset,file='output/data')
Written by Oliver Porth, 28.05.2018
"""


import numpy as np
import struct


class read():
    """Load binary postrad data"""

    def __init__(self,offset,file='data',headersize=256,nvars=8,get=1):
        self.offset=offset
        self.filenameout = file
        self.headersize = headersize
        self.nvars =8

        self.indices={'r':0,'theta':1,'phi':2,'rho':0,'vr':1,'vtheta':2,'vphi':3,'p':4,'br':5,'btheta':6,'bphi':7}

        self.data=-1
        self.grid=-1
        self.header=-1

        self.makefilenames()
        
        if get != None:
            self.getAll()

    def getAll(self):
        self.openfiles()
        self.read()
        self.closefiles()
        
    def makefilenames(self):
        self.filename_vars = self.filenameout+str(self.offset).zfill(4)+'.blk'
        self.filename_grid = self.filenameout+'_grid.blk'

    def openfiles(self):
        self.file_vars = open(self.filename_vars,'rb')
        self.file_grid = open(self.filename_grid,'rb')

    def closefiles(self):
        self.file_vars.close()
        self.file_grid.close()

    def read(self):
        self.read_header()
        self.set_dtype()
        self.read_grid()
        self.read_data()
        
    def read_header(self):
        file_vars = self.file_vars
        file_vars.seek(0)
        nr = struct.unpack('i',file_vars.read(4)) [0]
        ntheta = struct.unpack('i',file_vars.read(4)) [0]
        nphi = struct.unpack('i',file_vars.read(4)) [0]
        t = struct.unpack('d',file_vars.read(8)) [0]
        a = struct.unpack('d',file_vars.read(8)) [0]
        r_in = struct.unpack('d',file_vars.read(8)) [0]
        theta_in = struct.unpack('d',file_vars.read(8)) [0]
        phi_in = struct.unpack('d',file_vars.read(8)) [0]
        r_out = struct.unpack('d',file_vars.read(8)) [0]
        theta_out = struct.unpack('d',file_vars.read(8)) [0]
        phi_out = struct.unpack('d',file_vars.read(8)) [0]
        gammahat = struct.unpack('d',file_vars.read(8)) [0]
        hslope  = struct.unpack('d',file_vars.read(8)) [0]
        hslope  = 0.25 # was incorrectly set in codeComparison files
        imetric = struct.unpack('i',file_vars.read(4)) [0]
        dummy = struct.unpack('i',file_vars.read(4)) [0]
        dim = struct.unpack('i',file_vars.read(4)) [0]
        isp = struct.unpack('i',self.file_vars.read(4)) [0]
        if (isp == -1):
            single_precision = True
        else:
            single_precision = False
        
        self.header = {'nr':nr, 'ntheta':ntheta, 'nphi':nphi,'t':t,'a':a,'r_in':r_in,'theta_in':theta_in,'phi_in':phi_in,'r_out':r_out,'theta_out':theta_out,'phi_out':phi_out,'gammahat':gammahat,'hslope':hslope,'imetric':imetric,'dim':dim,'single_precision':single_precision}
    
    def set_dtype(self):
        if (self.header['single_precision']):
            self.__dtype_str = 'f'
        else:
            self.__dtype_str = 'd'

    def read_data(self):
        file_vars = self.file_vars
        header = self.header
        file_vars.seek(self.headersize)
            
        len_bytes = header['nphi']*header['ntheta']*header['nr']*self.nvars
        data = np.array(struct.unpack(self.__dtype_str*len_bytes,file_vars.read())).reshape(header['nphi'],header['ntheta'],header['nr'],self.nvars)
        
        self.data = data

    def read_grid(self):
        file_grid = self.file_grid
        header = self.header
        file_grid.seek(0)
        len_bytes = header['nphi']*header['ntheta']*header['nr']*3
        data = np.array(struct.unpack(self.__dtype_str*len_bytes,file_grid.read())).reshape(header['nphi'],header['ntheta'],header['nr'],3)
        
        self.grid = data
