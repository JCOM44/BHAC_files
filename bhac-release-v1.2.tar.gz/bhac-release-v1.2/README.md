# This is the version 1.2 release of BHAC


## Release highlights:

* electronphysics (heating and cooling), contribued by Yosuke Mizuno [https://ui.adsabs.harvard.edu/abs/2023MNRAS.518..405D]
* bugfixes (IO, shells, nblocks>ncores related)

## Note on upgrading
to upgrade a setup from v1.1 to v1.2 you need to follow these steps:
* In your setup .t files, change all the `include 'amrvacdef.f90'` to `use mod_amrvacdef`
* update the makefile in your run directory, most conveniently this is done as follows:
`$BHAC_DIR/setup.pl -s >tmp && rm makefile && bash tmp && rm tmp`
which saves the options, gets a fresh makefile from the repo, adding the options, and then removes the saved options again.

This was a long overdue change since we now get rid of the main legacy common blocks in favor of modules (newer intel compilers had issues with that)


This program is free software; you can redistribute it and/or modify it under the terms of the GPLv3.
Link to source code repository

Created by Oliver Porth and the BHAC development team 

Hector Olivares, Yosuke Mizuno, Ziri Younsi, Luciano Rezzolla, Elias Most, Bart Ripperda, Fabio Bacchini and Lukas Weih.

at Goethe University Frankfurt within the ERC Synergy grant “BlackHoleCam: Imaging the Event Horizon of Black Holes" (Grant No. 610058), PI: H. Falcke, M. Kramer, L. Rezzolla.  

The public version will receive frequent updates and improvements from the private development repository. There can still be bugs and issues. It is users' responsibility to guarantee quality and correctness of the results. Any feedbacks and contributions are welcome, but please understand that we may not be able to respond to all of them because of limited resources. 
Usage instructions
If you make use of this software release, you are morally obliged to cite the following papers in scientific communications:

Porth, O.; Olivares, H.; Mizuno, Y.; Younsi, Z.; Rezzolla, L.; Moscibrodzka, M.; Falcke, H. and Kramer, M.
The black hole accretion code
Computational Astrophysics and Cosmology, 2017, 4, 1

Constrained transport and adaptive mesh refinement in the Black Hole Accretion Code
Hector Olivares, Oliver Porth, Jordy Davelaar, Elias R. Most, Christian M. Fromm, Yosuke Mizuno , Ziri Younsi  and Luciano Rezzolla
A&A 2019 …
https://ui.adsabs.harvard.edu/abs/2019arXiv190610795O/abstract

We consider it a courtesy that you notify us (contact below) of your intended use.  
If you make useful additions to this software, we kindly ask you to contact the main developers, so upgrades can be made available to the wider community.  

## Documentation
Please refer to the documentation under src/doc/index.html or https://bhac.science/documentation/ for usage instructions.

## Contact
For general inquiries: Oliver Porth [o.porth@uva.nl], Luciano Rezzolla [rezzolla@itp.uni-frankfurt.de], Hector Olivares [H.Olivares@astro.ru.nl]
